let balls = [];
let G = 0.2;
let colorList = ['#ffadad', '#ffd6a5', '#fdffb6', '#caffbf', '#9bf6ff'];
let wind = 0;

function setup() {
  createCanvas(400, 400);
  for (let i = 0; i < 10; i++) {
    balls.push(new Ball(
      random(20, width - 20),
      random(20, height - 20),
      random(-2, 2),
      random(-2, 2),
      15,
      random(colorList)
    ));
  }
  ellipseMode(RADIUS);
}

function draw() {
  background(240);

  for (let b of balls) {
    b.applyGravity();
    b.move();
    b.checkEdges();
    b.draw();
  }

  // Check for circle-to-circle collisions
  for (let i = 0; i < balls.length; i++) {
    for (let j = i + 1; j < balls.length; j++) {
      balls[i].checkCollision(balls[j]);
    }
  }
}

function keyPressed() {
  if (key === ' ') {
    wind = random(-1, 1);
    for (let b of balls) {
      b.applyWind(wind);
    }
  }
}

class Ball {
  constructor(x, y, dx, dy, r, c) {
    this.x = x;
    this.y = y;
    this.dx = dx;
    this.dy = dy;
    this.r = r;
    this.c = c;
  }

  applyGravity() {
    this.dy += G;
  }

  applyWind(force) {
    this.dx += force;
  }

  move() {
    this.x += this.dx;
    this.y += this.dy;
  }

  checkEdges() {
    if (this.x < this.r) {
      this.x = this.r;
      this.dx *= -1;
    }
    if (this.x > width - this.r) {
      this.x = width - this.r;
      this.dx *= -1;
    }
    if (this.y < this.r) {
      this.y = this.r;
      this.dy *= -1;
    }
    if (this.y > height - this.r) {
      this.y = height - this.r;
      this.dy *= -1;
    }
  }

  draw() {
    fill(this.c);
    circle(this.x, this.y, this.r);
  }

  checkCollision(other) {
    let dx = other.x - this.x;
    let dy = other.y - this.y;
    let distSq = dx * dx + dy * dy;
    let minDist = this.r + other.r;

    if (distSq < minDist * minDist) {
      let dist = sqrt(distSq);
      let overlap = (minDist - dist) / 2;
      let offsetX = (dx / dist) * overlap;
      let offsetY = (dy / dist) * overlap;

      this.x -= offsetX;
      this.y -= offsetY;
      other.x += offsetX;
      other.y += offsetY;

      let tempDx = this.dx;
      let tempDy = this.dy;
      this.dx = other.dx;
      this.dy = other.dy;
      other.dx = tempDx;
      other.dy = tempDy;
    }
  }
}